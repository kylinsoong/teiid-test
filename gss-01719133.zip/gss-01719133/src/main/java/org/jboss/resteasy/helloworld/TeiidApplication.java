package org.jboss.resteasy.helloworld;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class TeiidApplication extends Application {

}
