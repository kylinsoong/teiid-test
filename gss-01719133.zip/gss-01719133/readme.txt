
Steps to run

1. build

~~~
mvn clean install
~~~

2. deploy 01719133.war to JDV 6.2

3. Test via http://localhost:8080/01719133/test


